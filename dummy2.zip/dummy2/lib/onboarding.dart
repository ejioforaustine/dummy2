import 'package:dummy2/content_model.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Onbording extends StatefulWidget {

  @override
  _OnbordingState createState() => _OnbordingState();
}
class _OnbordingState extends State<Onbording>
{
  @override
  // TODO: implement widget
  // TODO: implement widget
  Widget build (BuildContext context) {
    return Scaffold(
      body: PageView.builder(
          itemCount: contents.length,
          itemBuilder: (_,i){
            return Column(
              children: [

                Image.asset(contents[i].image,width: 500,height: 300,fit: BoxFit.contain,),

                Text( contents[i].title,
                  style: GoogleFonts.signikaNegative(letterSpacing: 2,fontWeight: FontWeight.w900,fontSize: 10),),
                SizedBox(height: 30,),


                Text(contents[i].description,
                  style: GoogleFonts.signikaNegative(letterSpacing: 1,fontWeight: FontWeight.w900,fontSize: 15,color: Colors.black45),)

              ],
            );
    },
      ));
  }
}