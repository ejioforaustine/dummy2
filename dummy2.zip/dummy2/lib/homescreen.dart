
import 'package:dummy2/Cart.dart';
import 'package:dummy2/Profile.dart';
import 'package:dummy2/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'foryoupage.dart';


class Homescreen extends StatelessWidget {
  // This widget is the root of your application.
  
  @override
  Widget build(BuildContext context) {
    
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.indigo,
      ),
      home: MyHomePage(title: '',name: 'Austine',),
    );
  }


}
class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title,required this.name}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;
  final String name;





  @override
  _MyHomePageState createState() => _MyHomePageState();
}
class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;
  final List<Widget> _children=[
    Center(


      child: ListView(

        children: [




          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Padding(
                padding: const EdgeInsets.only(top: 30.0),
                child: Row(
                  children: [
                    Container(height: 60,width: 60,
                      decoration: BoxDecoration(image: DecorationImage(image: AssetImage('assets/images/dummy-profile.png',),fit: BoxFit.contain,
                      ), shape: BoxShape.circle,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: new Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [


                          Text('Welcome !', style: GoogleFonts.dmSerifDisplay(letterSpacing: 1,fontWeight: FontWeight.w900,fontSize: 15,color: Colors.blue),),
                          SizedBox(height: 10,),
                          Padding(
                            padding: const EdgeInsets.only(left: 1.0),
                            child: Text('Flavius Francis',style: GoogleFonts.lobsterTwo(letterSpacing: 0,fontWeight: FontWeight.w700,fontSize: 20),),
                          )


                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 150.0),
                      child: Icon(Icons.notifications_sharp, size: 30,color: Colors.red,),
                    )
                  ],
                  //Profile widget

                ),
              ), //profile widget
              SizedBox(height: 30,),
              Container(
                alignment: Alignment.center,
                height: 50,
                width: double.infinity,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.white),
                child: Row(children: [
                  new Flexible(child: TextFormField(
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w700),


                    decoration: const InputDecoration(border:InputBorder.none,


                        hintText: "Search here", hintStyle: TextStyle(color: Colors.black45)),)),
                  Icon(Icons.search_outlined,size: 30,color: Colors.black45,)
                ],),
              ), // search widget
              SizedBox(height: 30,),
              // Search widget

            ],

          ),
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: new Row(
                  children: [
                    Text('Hot Picks',style: GoogleFonts.droidSerif(fontSize: 15, fontWeight: FontWeight.bold,color: Colors.black),),
                    SizedBox(width: 5,),
                    Container(height: 20,width:20,

                        child: Image.asset('assets/images/Emoji.png', fit: BoxFit.contain,)),

                    SizedBox(width: 235,),

                    Text('See all',style: GoogleFonts.droidSerif(fontSize: 12, fontWeight: FontWeight.bold,color: Colors.blue))
                  ],

                ),
              ),
            ],

          ), //Hotpicks widget

          SizedBox(height: 20,),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.all(10.0,),

            child:Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 350,
                  width: 250,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.pink[200],),
                  child: Stack(children: [
                    Image.asset('assets/images/nike3.png'),
                    Image.asset('assets/images/nikelogo-removebg-preview.png',width: 40,height: 40,),
                    Padding(
                      padding: const EdgeInsets.only(top: 290.0, left: 20,),
                      child: Column(
                        children: [
                          Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w700,fontSize: 17,color: Colors.white),),
                          SizedBox(height: 5,),
                          Text('\$212',style: GoogleFonts.droidSans(fontWeight: FontWeight.bold,fontSize: 20, color: Colors.white)),
                        ],
                      ),
                    )
                  ]),
                ),
                SizedBox(width: 10,),
                Container(
                  height: 350,
                  width: 250,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.indigo[200],),
                  child: Stack(children: [
                    Padding(
                      padding: const EdgeInsets.only(top:70.0),
                      child: Image.asset('assets/images/nikeshoe2.png'),
                    ),
                    Image.asset('assets/images/nikelogo-removebg-preview.png',width: 40,height: 40,),
                    Padding(
                      padding: const EdgeInsets.only(top: 290.0, left: 20,),
                      child: Column(
                        children: [
                          Text('Classic Leaver', style: GoogleFonts.droidSans(fontWeight: FontWeight.w700,fontSize: 17,color: Colors.white),),
                          SizedBox(height: 5,),
                          Text('\$ 515',style: GoogleFonts.droidSans(fontWeight: FontWeight.bold,fontSize: 20, color: Colors.white)),
                        ],
                      ),
                    )
                  ]),
                ),
                SizedBox(width: 10,),
                Container(
                  height: 350,
                  width: 250,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.redAccent[100],),
                  child: Stack(children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 70.0),
                      child: Image.asset('assets/images/nike4-removebg-preview.png'),
                    ),
                    Image.asset('assets/images/nikelogo-removebg-preview.png',width: 40,height: 40,),
                    Padding(
                      padding: const EdgeInsets.only(top: 290.0, left: 20,),
                      child: Column(
                        children: [
                          Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w700,fontSize: 17,color: Colors.white),),
                          SizedBox(height: 5,),
                          Text('\$212',style: GoogleFonts.droidSans(fontWeight: FontWeight.bold,fontSize: 20, color: Colors.white)),
                        ],
                      ),
                    )
                  ]),
                ),
                SizedBox(width: 10,),
                Container(
                  height: 350,
                  width: 250,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.blue[200],),
                  child: Stack(children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 70.0),
                      child: Image.asset('assets/images/nike5-removebg-preview.png'),
                    ),
                    Image.asset('assets/images/nikelogo-removebg-preview.png',width: 40,height: 40,),
                    Padding(
                      padding: const EdgeInsets.only(top: 290.0, left: 20,),
                      child: Column(
                        children: [
                          Text('Nike Runner pro', style: GoogleFonts.droidSans(fontWeight: FontWeight.w700,fontSize: 17,color: Colors.white),),
                          SizedBox(height: 5,),
                          Text('\$2,782',style: GoogleFonts.droidSans(fontWeight: FontWeight.bold,fontSize: 20, color: Colors.white)),
                        ],
                      ),
                    )
                  ]),
                ),
                SizedBox(width: 10,),
                Container(
                  height: 350,
                  width: 250,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.teal[200],),
                  child: Stack(children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 70.0),
                      child: Image.asset('assets/images/nike6-removebg-preview.png'),
                    ),
                    Image.asset('assets/images/nikelogo-removebg-preview.png',width: 40,height: 40,),
                    Padding(
                      padding: const EdgeInsets.only(top: 290.0, left: 20,),
                      child: Column(
                        children: [
                          Text('Soccer leg revision', style: GoogleFonts.droidSans(fontWeight: FontWeight.w700,fontSize: 17,color: Colors.white),),
                          SizedBox(height: 5,),
                          Text('\$1,712',style: GoogleFonts.droidSans(fontWeight: FontWeight.bold,fontSize: 20, color: Colors.white)),
                        ],
                      ),
                    )
                  ]),
                ),

              ],
            )
            ,
          ),
          SizedBox(height: 10,),
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: new Row(
                  children: [
                    Text('For you',style: GoogleFonts.droidSerif(fontSize: 15, fontWeight: FontWeight.w900,color: Colors.black),),
                    SizedBox(width: 5,),
                    Container(height: 20,width:20,

                    ),

                    SizedBox(width: 235,),




                  ],

                ),
              ),
            ],

          ),

          SizedBox(height: 15,),

          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [

              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.white,),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded, color: Colors.red,),
                      ),
                      Image.asset('assets/images/niky6.jpg',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack.jpg',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$212',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),
                  SizedBox(width: 10,),
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Color(0xFFF3F3F3),),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded,color: Colors.black38, ),
                      ),
                      Image.asset('assets/images/niky4.jpg',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack-removebg-preview.png',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$342',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),

                ],
              ),

              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.white,),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded, color: Colors.black38,),
                      ),
                      Image.asset('assets/images/niky5.png',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack.jpg',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$2,112',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),
                  SizedBox(width: 10,),
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Color(0xFFF3F3F3),),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded,color: Colors.black38, ),
                      ),
                      Image.asset('assets/images/niky3.jpg',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack-removebg-preview.png',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$1,342',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),

                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Color(0xFFF3F3F3)),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded, color: Colors.red,),
                      ),
                      Image.asset('assets/images/nike2.jpg',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack.jpg',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$212',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),
                  SizedBox(width: 10,),
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Color(0xFFF3F3F3),),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded,color: Colors.black38, ),
                      ),
                      Image.asset('assets/images/niky5.png',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack-removebg-preview.png',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('SneakerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$4,742',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),

                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.white,),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded, color: Colors.red,),
                      ),
                      Image.asset('assets/images/niky6.jpg',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack.jpg',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$212',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),
                  SizedBox(width: 10,),
                  Container(
                    height: 170,
                    width: 170,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Color(0xFFF3F3F3),),
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0, top: 140),
                        child: Icon(Icons.add_box_rounded, color: Colors.blue,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 140.0,top: 5),
                        child: Icon(Icons.favorite_rounded,color: Colors.black38, ),
                      ),
                      Image.asset('assets/images/niky5.png',width: 130,height: 130,),
                      Image.asset('assets/images/nikeblack-removebg-preview.png',width: 40,height: 40,),
                      Padding(
                        padding: const EdgeInsets.only(top: 140.0, left: 10,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('RunnerKick', style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 10,color: Colors.black87),),
                            SizedBox(height: 1,),
                            Text('\$342',style: GoogleFonts.droidSans(fontWeight: FontWeight.w900,fontSize: 12, color: Colors.black)),
                          ],
                        ),
                      )
                    ]),
                  ),

                ],
              ),
            ],
          )// FOR YOU
        ],

      ),
    ),
    foryoupage(),
    Cart(),
    profile(),




  ];


  void _onItemTapped (int index) {
    setState(() {
      _selectedIndex = index;
    });
  }



  @override
  Widget build(BuildContext context) {
    
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      backgroundColor:  const Color(0xFFF0F0F0 ),


      body:
      _children[_selectedIndex],


      bottomNavigationBar: BottomNavigationBar(
         unselectedItemColor: Colors.black54,


        items: const <BottomNavigationBarItem> [

             BottomNavigationBarItem(
                  icon: Icon(Icons.home,size: 26,),
                label: '',),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite_rounded,color: Colors.red),
            label: '',),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart,color: Colors.black54),
            label: '',),
          BottomNavigationBarItem(
            icon: Icon(Icons.person,color: Colors.black54,),
            label: '',),
        ],

            currentIndex: _selectedIndex,
        selectedItemColor: Colors.indigo,
             onTap: _onItemTapped,
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}