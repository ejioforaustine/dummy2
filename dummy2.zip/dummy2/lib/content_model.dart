


import 'package:flutter/cupertino.dart';

class UnbordingContent {
  String image;
  String title;
  String description;



  UnbordingContent ({required this.image,required this.title,required this.description});

}

List<UnbordingContent> contents = [
  UnbordingContent(title: 'A million miles with a step',
    description: 'About a million pair to explore',
    image: 'assets/images/hdshoe.png'

  ),

  UnbordingContent(title: 'Let\'s the journey start',
      description: 'Find the best pair to fit your lifestyle and fulfill your life',
      image: 'assets/images/adidas2.png'

  ),
];

